/* These stubs are provided so that autoconf can check library
 * versions using C symbols only */

extern void libvampsdk_v_2_9_present(void) { }
extern void libvampsdk_v_2_8_present(void) { }
extern void libvampsdk_v_2_7_1_present(void) { }
extern void libvampsdk_v_2_7_present(void) { }
extern void libvampsdk_v_2_6_present(void) { }
extern void libvampsdk_v_2_5_present(void) { }
extern void libvampsdk_v_2_4_present(void) { }
extern void libvampsdk_v_2_3_1_present(void) { }
extern void libvampsdk_v_2_3_present(void) { }
extern void libvampsdk_v_2_2_1_present(void) { }
extern void libvampsdk_v_2_2_present(void) { }
extern void libvampsdk_v_2_1_present(void) { }
extern void libvampsdk_v_2_0_present(void) { }
