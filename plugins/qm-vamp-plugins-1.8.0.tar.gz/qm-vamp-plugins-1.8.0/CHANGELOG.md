
QM Vamp Plugins v1.8 (January 2020)
-----------------------------------

 - Fix incorrect chromagram tuning in key detector, improving
   key detector output (thanks to Daniel Schürmann)
 - Add Merged Key Strength Plot output to key detector
 - Fix incorrect time alignment of tonal-change plugin outputs


QM Vamp Plugins v1.7.1 (September 2015)
---------------------------------------

 - Improve output format of segmenter
 - Add parameters to tempo tracker
 - Bug fixes and build-system updates


QM Vamp Plugins v1.7 (April 2011)
---------------------------------

 - Re-release with source code under GPL


QM Vamp Plugins v1.6.1 (October 2009)
-------------------------------------

 - Fix failure to smooth onset detection function correctly, which
   caused onset and beat trackers occasionally to miss onsets or find
   spurious ones
 

QM Vamp Plugins v1.6 (July 2009)
--------------------------------

 - Add the Adaptive Spectrogram plugin
 - Add the Polyphonic Transcription plugin
 - Add the Wavelet Scalogram plugin
 - Add the Bar and Beat Tracker plugin
 - Add a new method for the beat tracker


QM Vamp Plugins v1.5 (December 2008)
------------------------------------

 - Reliability and performance improvements
 

QM Vamp Plugins v1.4 (February 2008)
------------------------------------

 - Add Segmenter plugin
 - Add Similarity plugin
 - Add MFCC plugin
 - Add key-strength plot output to Key Detector plugin
 

QM Vamp Plugins v1.3 (December 2007)
------------------------------------

 - Minor bugfix release
 

QM Vamp Plugins v1.2 (September 2007)
-------------------------------------

 - First external release
 - Including: Onset Detector, Beat Tracker, Key Detector, Chromagram,
   Constant-Q Spectrogram, and Tonal-Change Detector

